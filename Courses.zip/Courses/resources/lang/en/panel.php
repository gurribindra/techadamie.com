<?php

return [
    'site_title' => 'Techadamie',
];
