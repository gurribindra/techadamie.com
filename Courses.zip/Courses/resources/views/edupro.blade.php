@extends('layouts.main')

@section('content')

        <!-- About Start -->
        <section class="popular-course-section">
            <div class="container">
                <div class="row mt-120">
                    
                    <div class="col-lg-12 col-md-12">
                        
<p>The buck doesn’t stop at only academics accomplishments. Increased focus on apprenticeship in chosen field of professions brings us the defining question – after all which field should our kids choose? We got you covered with Edupro (Pro stands for Professional and Proficient).  Hence, the carefully designed career guidance program, wherein an expert mentor, based on your aptitude, will help you choose a right path for career growth. A career that utilizes your full potential. Expert, experienced and sought after career counsellors from India will assist you in this crucial process.</p>
<p>This will be, again, conducted online, covering your child’s need for a dedicated and personalized counselling. The career guidance is provided by the occupation or education in future which goes well with their capabilities, skills and interest and suits their personality, so that their career becomes an epitome of success.</p>
<ul>
    <li>Prepaid Plans with affordable pricing and payment terms.</li>
<li>Expert Guidance</li>
<li>Flexible Timings</li>
<li>Best suitable career options per your child’s aptitude.</li>
</ul>

 </div>
</div>

 </div>
          
        </section>

        <!-- About End -->
     

        <!-- Funfact Start -->
        <!-- <section class="funfact-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="sec-title">Our Global Community</h2>
                        <p class="sec-desc">
                            Join thousand of instructors and earn money hassle free!
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="funfact-item-3">
                            <img src="assets/images/home3/f3.png" alt=""/>
                            <h2><span data-counter="27" class="timer">27</span></h2>
                            <p>Million Learners</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="funfact-item-3 ml-15">
                            <img src="assets/images/home3/f4.png" alt=""/>
                            <h2><span data-counter="4" class="timer">4</span>.6</h2>
                            <p>Million Graduates</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="funfact-item-3 ml-40">
                            <img src="assets/images/home3/f5.png" alt=""/>
                            <h2><span data-counter="1400" class="timer">1400</span>+</h2>
                            <p>Online Courses</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="funfact-item-3 righ-align">
                            <img src="assets/images/home3/f7.png" alt=""/>
                            <h2><span data-counter="175" class="timer">175</span></h2>
                            <p>Countries</p>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- Funfact End -->

  
       <p>&nbsp;</p>
       <p>&nbsp;</p>

       @endsection