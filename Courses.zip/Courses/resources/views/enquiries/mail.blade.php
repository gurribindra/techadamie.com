<h1>Hello,</h1>
<p>You had a new enquiry from Techadammie. Please find below details.</p>

<table border=1 style="width: 50%;text-align: left;border-spacing: 0px;
    border-style: solid;">
  <tr>
    <th>First Name</th>
    <td>{{ $first_name }}</td>
  </tr>
  <tr>
    <th>Last Name</th>
    <td>{{ $last_name }}</td>
  </tr>
  <tr>
    <th>Email</th>
    <td>{{ $email }}</td>
  </tr>
  <tr>
     <th>Phone Number</th>
    <td>{{ $phone_number }}</td> 
  </tr>
  <tr>
     <th>Child 1 Grade</th>
    <td>{{ $gd1_grade }}</td> 
  </tr>
  <tr>
     <th>Requested Subject</th>
    <td>{{ $gd1_sub }}</td> 
  </tr>
  <tr>
     <th>Child 2 Grade</th>
    <td>{{ $gd2_grade }}</td> 
  </tr>
  <tr>
     <th>Requested Subject</th>
    <td>{{ $gd2_sub }}</td> 
  </tr>
  <tr>
     <th>Child 3 Grade</th>
    <td>{{ $gd3_grade }}</td> 
  </tr>
  <tr>
     <th>Requested Subject</th>
    <td>{{ $gd3_sub }}</td> 
  </tr>
  <tr>
     <th>Child 4 Grade</th>
    <td>{{ $gd4_grade }}</td> 
  </tr>
  <tr>
     <th>Requested Subject</th>
    <td>{{ $gd4_sub }}</td> 
  </tr>
  <tr>
     <th>Timezone</th>
    <td>{{ $time_zone }}</td> 
  </tr>
</table>



<p>Thanks</p>