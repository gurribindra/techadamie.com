@extends('layouts.main')

@section('content')

       <!-- About Start -->
        <section class="popular-course-section">
            <div class="container">
                <div class="row mt-120">
                    
                    <div class="col-lg-12 col-md-12">
                        
                           <p> Our public education may leave a lot to be desired. Education levels and quality will decide the lifestyle our children will live.  We know education is like a link in the chain of life, the chain has to be strong throughout. Without primary education, secondary education will be close to impossible to comprehend. There needs to be a firm foundational knowledge before going into higher levels of learning. Secondary education is also important for the same reason- that it is yet another level of knowledge necessary as a foundation for even further studies like engineering, computers, medicines, arts and social sciences.</p>

                            <p>Keeping this fundamentals in mind, Techadamie brings you Eduedge: A one on one tutoring system to help your child learn any subjects of any grade from K through 12. The classes are conducted online by B.Ed. certified teachers from India. Being a dedicated one-on-one session, the focus will be on your child alone, which in turn will ensure better understanding of any subject and better scoring on tests.
                            </p>
 </div>
</div>
 <div class="row">
 <div class="col-lg-8 col-md-8">
    <p><strong>Eduedge: </strong> 1 on 1 tutoring to help your child excel in in academics </p>
    <ul>
        <li>Eduedge Support – Help your child reach the top of his class.</li>
        <li>Eduedge Excel – Bring your child at par with other children globally in STEM subjects.</li>
        <li>Eduedge Prosper – A specially tailored homeschooling program to help your child becime college and career ready for anywhere in the world !</li>
    </ul>
 </div>
    <p>Be prepared to be amazed by the affordability of our offering! Ask us for a customized structure to suit your child’s needs.
    </p>
</div>

 </div>
          
        </section>

        <!-- About End -->
        @include('partials.eduedge-1')


        
        <!-- Funfact Start -->
        <!-- <section class="funfact-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="sec-title">Our Global Community</h2>
                        <p class="sec-desc">
                            Join thousand of instructors and earn money hassle free!
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="funfact-item-3">
                            <img src="assets/images/home3/f3.png" alt=""/>
                            <h2><span data-counter="27" class="timer">27</span></h2>
                            <p>Million Learners</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="funfact-item-3 ml-15">
                            <img src="assets/images/home3/f4.png" alt=""/>
                            <h2><span data-counter="4" class="timer">4</span>.6</h2>
                            <p>Million Graduates</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="funfact-item-3 ml-40">
                            <img src="assets/images/home3/f5.png" alt=""/>
                            <h2><span data-counter="1400" class="timer">1400</span>+</h2>
                            <p>Online Courses</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="funfact-item-3 righ-align">
                            <img src="assets/images/home3/f7.png" alt=""/>
                            <h2><span data-counter="175" class="timer">175</span></h2>
                            <p>Countries</p>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- Funfact End -->

  
       <p>&nbsp;</p>
       <p>&nbsp;</p>

       @endsection