 <!-- Course Start -->
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h2 class="sec-title"><span> Our Offerings:  </span>Edupro</h2>
                    
                </div>
                
            </div>



<div class="row">
                    <div class="col-md-12">
                      
                        <p class="sec-desc">
                            Online education is a flexible instructional delivery system that encompasses any<br> kind of learning that takes place via the Internet.<br>
                            Sometimes a person that connects with you is a better way to learn! Edupro gives you the benefit of both and <br>allows your child to grow in mixed method of traditional with modern means.
                        </p>
                    </div>
                </div>

        </div>
    </section>