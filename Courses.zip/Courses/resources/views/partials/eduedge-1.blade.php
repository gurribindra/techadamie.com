 <!-- Course Start -->
    <section class="popular-course-section">
        <div class="container">
           <div class="row">
                <div class="col-md-8">
                    <h2 class="sec-title"><span>Subjects Covered</span></h2>
                </div>
                
            </div>
<div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-general-math.png" alt="">
                            </div>
                            <h4><a href="">General Math</a></h4>
                         
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-calculus.png" alt="">
                            </div>
                            <h4><a href="">Calculus</a></h4>
                            
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-algebra.png" alt="">
                            </div>
                            <h4><a href="">Algebra</a></h4>
                           
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-reading.png" alt="">
                            </div>
                            <h4><a href="">Reading</a></h4>
                            
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-general-science.png" alt="">
                            </div>
                            <h4><a href="">General Science</a></h4>
                            
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-trigonometry.png" alt="">
                            </div>
                            <h4><a href="">Trigonometry</a></h4>
                            
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-geometry.png" alt="">
                            </div>
                            <h4><a href="">Geometry</a></h4>
                           
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-hindi.png" alt="">
                            </div>
                            <h4><a href="">Hindi</a></h4>
                            
                        </div>
                    </div>
                </div>

<div class="col-lg-12">
       
<ul>
    <li>Customizable schedule as per each child’s availability.</li>
<li>Group communication between teachers, parents and students through Whatsapp.</li>
<li>On demand recording of class session.</li>
<li>Prepaid plans with affordable pricing and payment terms.</li>
<li>Special programs to identify scholarships and reduce financial burden and avoid student loans.</li>
</ul>
</div>

        </div>
    </section>