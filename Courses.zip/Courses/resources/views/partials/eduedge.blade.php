 <!-- Course Start -->
    <section class="popular-course-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h2 class="sec-title"><span>Our Offerings:</span> Eduedge </h2>
                </div>
                
            </div>



<div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-general-math.png" alt="">
                            </div>
                            <h4><a href="single-course.html">General Math</a></h4>
                         
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-calculus.png" alt="">
                            </div>
                            <h4><a href="single-course.html">Calculus</a></h4>
                            
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-algebra.png" alt="">
                            </div>
                            <h4><a href="single-course.html">Algebra</a></h4>
                           
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-reading.png" alt="">
                            </div>
                            <h4><a href="single-course.html">Reading</a></h4>
                            
                        </div>
                    </div>
                </div>


                
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-general-science.png" alt="">
                            </div>
                            <h4><a href="single-course.html">General Science</a></h4>
                            
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-trigonometry.png" alt="">
                            </div>
                            <h4><a href="single-course.html">Trigonometry</a></h4>
                            
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-geometry.png" alt="">
                            </div>
                            <h4><a href="single-course.html">Geometry</a></h4>
                           
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="course-item-2 text-center">
                            <div class="course-thumb">
                                <img src="assets/images/course/eduedge/eduedge-prosper-hindi.png" alt="">
                            </div>
                            <h4><a href="single-course.html">Hindi</a></h4>
                            
                        </div>
                    </div>
                </div>



        </div>
    </section>