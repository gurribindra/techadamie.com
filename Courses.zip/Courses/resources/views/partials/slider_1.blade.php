 <!-- Hero Slider Start -->
        <div class="hero-slider-section">
            <div class="hero-slider owl-carousel">
                
                <!-- Single Slider item  -->
                <div class="single-slide bg-img d-flex align-items-center" data-bg-image="assets/images/mentor-01.jpg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="slider-content">
                                    <div class="sub animated">Our kids are truly Global citizens.</div>
                                    <h3 class="animated">
                                        They deserve the education  <br>at par with Global standards.
                                    </h3>
                                    <!-- <a href="#" class="animated bisylms-btn-3">Let's Go</a> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Single Slider item  -->
          
                <!-- Single Slider item  -->
                <div class="single-slide bg-img d-flex align-items-center" data-bg-image="assets/images/mentor-02.jpg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="slider-content">
                                    <div class="sub animated">Life is a roller-coaster ride. </div>
                                    <h3 class="animated">
                                       Don’t prepare the road for your kids. <br> Prepare your kids for the road.
                                    </h3>
                                    <!-- <a href="#" class="animated bisylms-btn-3">Browse Online Courses</a> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Single Slider item  -->
                <div class="single-slide bg-img d-flex align-items-center" data-bg-image="assets/images/mentor-03.jpg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="slider-content">
                                    <div class="sub animated">Eduedge</div>
                                    <h3 class="animated">
                                      1-on-1 mentoring for your child to <br> grasp any subject from K-12

                                    </h3>
                                    <a href="#" class="animated bisylms-btn-3">Our Offerings</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



            </div>
        </div>
        <!-- Hero Slider End -->